<?php
            include '../connection/connectiondb.php';
            $mydb1 = new model();
            $connobj = $mydb1->openConn();
            $result = $mydb1->showBuyedMovieInfo($connobj, "customer_buyed_movie");
            if ($result) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo
                    '<tr>
                    <td>' . $row['id'] . '</td>
              <td>' . $row['customer_name'] . '</td>
              <td>' . $row['movie_name'] . '</td>
              <td>' . $row['quantity'] . '</td>
              <td>' . $row['total_price_discount'] . '</td>
              <td>' . $row['per_ticket_price'] . '</td>
             
            </tr>';
                }
            }

            ?>
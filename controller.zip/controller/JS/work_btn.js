function login_to_register()
{
    window.location.href = './register.php';
}
function register_login()
{
    window.location.href = './login.php';
}
function manager()
{
    console.log("BTN CLICKED");
    window.location.href = './manager_login.php';
}